import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Users, Scissors, CalendarCheck, LogOut, Store, Settings, Package, Crown, UserCheck, Menu, X, Trophy } from 'lucide-react';

const AdminLayout: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const role = sessionStorage.getItem('userRole');
  const isAdmin = role === 'ADMIN';

  const handleLogout = () => {
    sessionStorage.removeItem('userRole');
    sessionStorage.removeItem('userId');
    navigate('/admin/login');
  };

  const navItems = [
    { path: '/admin/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/admin/appointments', icon: CalendarCheck, label: 'Agendamentos' },
    { path: '/admin/services', icon: Scissors, label: 'Serviços' },
    { path: '/admin/products', icon: Package, label: 'Produtos' },
    { path: '/admin/packages', icon: Crown, label: 'Pacotes' },
    { path: '/admin/subscribers', icon: UserCheck, label: 'Assinantes' },
    
    ...(isAdmin ? [
        { path: '/admin/barbers', icon: Users, label: 'Barbeiros' },
        { path: '/admin/levels', icon: Trophy, label: 'Níveis & XP' },
        { path: '/admin/settings', icon: Settings, label: 'Backup & Config' }
    ] : []),
  ];

  const SidebarContent = () => (
    <>
        <div className="p-6 border-b border-zinc-800 flex items-center gap-2">
          <div className="w-8 h-8 bg-amber-500 rounded-lg flex items-center justify-center text-zinc-900 font-bold">B</div>
          <span className="font-bold text-xl text-amber-500 tracking-tight">BarberPro</span>
        </div>
        
        <div className="px-6 pt-4 pb-2">
            <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider">
                {isAdmin ? 'Administrador' : 'Profissional'}
            </span>
        </div>
        
        <nav className="flex-1 p-4 space-y-1 pt-0 overflow-y-auto custom-scrollbar">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  isActive 
                    ? 'bg-amber-500/10 text-amber-500' 
                    : 'text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100'
                }`}
              >
                <item.icon size={20} />
                <span className="font-medium text-sm">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-zinc-800 space-y-2">
           <Link to="/" className="flex items-center gap-3 px-4 py-3 text-zinc-400 hover:text-zinc-100 transition-colors">
            <Store size={20} />
            <span className="text-sm">Ver Site</span>
          </Link>
          <button 
            onClick={handleLogout}
            className="flex items-center gap-3 px-4 py-3 text-red-400 hover:text-red-300 w-full transition-colors"
          >
            <LogOut size={20} />
            <span className="text-sm">Sair</span>
          </button>
        </div>
    </>
  );

  return (
    <div className="flex h-screen bg-zinc-950 text-zinc-100 overflow-hidden">
      {/* Desktop Sidebar */}
      <aside className="w-64 bg-zinc-900 border-r border-zinc-800 flex-col hidden md:flex">
        <SidebarContent />
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Mobile Header */}
        <div className="md:hidden bg-zinc-900 p-4 flex justify-between items-center border-b border-zinc-800 z-20 relative">
           <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-amber-500 rounded-lg flex items-center justify-center text-zinc-900 font-bold">B</div>
                <span className="font-bold text-lg text-amber-500">BarberPro</span>
           </div>
           <button 
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} 
                className="text-zinc-100 p-2 hover:bg-zinc-800 rounded-lg"
            >
                {isMobileMenuOpen ? <X size={24}/> : <Menu size={24}/>}
           </button>
        </div>

        {/* Mobile Sidebar Overlay & Menu */}
        {isMobileMenuOpen && (
            <div className="md:hidden absolute inset-0 z-10">
                {/* Backdrop */}
                <div 
                    className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
                    onClick={() => setIsMobileMenuOpen(false)}
                />
                {/* Drawer */}
                <div className="absolute top-[73px] left-0 bottom-0 w-64 bg-zinc-900 border-r border-zinc-800 flex flex-col animate-in slide-in-from-left-full duration-300 shadow-2xl">
                    <SidebarContent />
                </div>
            </div>
        )}

        {/* Page Content */}
        <div className="flex-1 overflow-auto p-4 md:p-8 max-w-7xl mx-auto w-full">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default AdminLayout;