import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Calendar as CalendarIcon, Clock, ChevronRight, CheckCircle, User, Scissors, ArrowLeft, Trophy, Star, LogOut, X, Lock, Camera, History, Share2, Edit3, Copy } from 'lucide-react';
import { Service, Barber, Appointment, ClientAccount, LevelConfig } from '../types';
import { storage } from '../utils/storage';
import { Link, useSearchParams } from 'react-router-dom';

const STEPS = ['Serviço', 'Profissional', 'Horário', 'Seus Dados', 'Confirmação'];

const BORDER_COLORS = [
    'border-zinc-700', // 1
    'border-orange-700', // 2
    'border-zinc-400', // 3
    'border-yellow-500', // 4
    'border-cyan-300', // 5
    'border-emerald-500', // 6
    'border-blue-500', // 7
    'border-red-600', // 8
    'border-indigo-500', // 9
    'border-purple-600' // 10
];

const LEVEL_NAMES = [
    'Iniciante', 'Bronze', 'Prata', 'Ouro', 'Platina', 
    'Esmeralda', 'Safira', 'Rubi', 'Diamante', 'Lenda'
];

const BookingPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedBarber, setSelectedBarber] = useState<Barber | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [clientData, setClientData] = useState({ name: '', phone: '', birthDate: '' });
  
  // Auth State
  const [currentClient, setCurrentClient] = useState<ClientAccount | null>(null);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false); // New Profile Modal
  const [isRegistering, setIsRegistering] = useState(false);
  
  // Level Config
  const [levelConfig, setLevelConfig] = useState<LevelConfig>({ xpPerService: 100, levels: [] });

  // Only show items that are services or subscriptions with duration > 0 (bookable)
  const services = useMemo(() => storage.getServices().filter(s => s.durationMinutes > 0), []);
  const barbers = useMemo(() => storage.getBarbers().filter(b => b.active), []);

  useEffect(() => {
      // 1. Check Referral Code in URL
      const refId = searchParams.get('ref');
      if (refId) {
          sessionStorage.setItem('referralCode', refId);
      }

      // 2. Check Session
      const storedSession = sessionStorage.getItem('clientSession');
      if (storedSession) {
          const client = JSON.parse(storedSession);
          // Refresh client data from storage to get latest XP
          const latestClient = storage.getClients().find(c => c.id === client.id);
          if (latestClient) {
              setCurrentClient(latestClient);
              setClientData({ name: latestClient.name, phone: latestClient.phone, birthDate: latestClient.birthDate || '' });
          }
      }
      setLevelConfig(storage.getLevelConfig());
  }, [searchParams]);

  const generateTimeSlots = () => {
    if (!selectedBarber || !selectedDate || !selectedService) return [];
    
    const slots = [];
    const startHour = 9;
    const endHour = 19;
    
    // Simulate current date validation
    const now = new Date();
    const isToday = selectedDate === now.toISOString().split('T')[0];
    const currentHour = now.getHours();
    const currentMinutes = now.getMinutes();

    for (let h = startHour; h < endHour; h++) {
      for (let m = 0; m < 60; m += 30) {
        if (isToday && (h < currentHour || (h === currentHour && m <= currentMinutes))) {
          continue;
        }

        const timeString = `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
        
        if (storage.isTimeSlotAvailable(selectedBarber.id, selectedDate, timeString, selectedService.durationMinutes)) {
          slots.push(timeString);
        }
      }
    }
    return slots;
  };

  const timeSlots = useMemo(() => generateTimeSlots(), [selectedBarber, selectedDate, selectedService]);

  const handleNext = () => {
    if (currentStep < STEPS.length - 1) setCurrentStep(c => c + 1);
  };
  
  const handleBack = () => {
    if (currentStep > 0) setCurrentStep(c => c - 1);
  };

  const handleSubmit = () => {
    if (!selectedService || !selectedBarber) return;

    const newAppointment: Appointment = {
      id: crypto.randomUUID(),
      serviceId: selectedService.id,
      barberId: selectedBarber.id,
      date: selectedDate,
      time: selectedTime,
      client: clientData,
      clientId: currentClient?.id, // Link to account if logged in
      status: 'pending',
      totalPrice: selectedService.price,
      createdAt: new Date().toISOString()
    };

    storage.saveAppointment(newAppointment);
    handleNext();
  };

  // Auth Handlers
  const handleAuthSubmit = (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const phone = formData.get('phone') as string;
      const password = formData.get('password') as string;

      if (isRegistering) {
          const name = formData.get('name') as string;
          const clients = storage.getClients();
          if (clients.find(c => c.phone === phone)) {
              alert('Telefone já cadastrado.');
              return;
          }
          const newClient: ClientAccount = {
              id: crypto.randomUUID(),
              name,
              phone,
              password,
              xp: 0,
              level: 1,
              totalAppointments: 0,
              joinedAt: new Date().toISOString(),
              referralCount: 0
          };
          const updated = [...clients, newClient];
          storage.saveClients(updated);
          
          // Check for Referral
          const referralCode = sessionStorage.getItem('referralCode');
          if (referralCode) {
              storage.incrementReferralCount(referralCode);
              sessionStorage.removeItem('referralCode'); // Consume
          }

          sessionStorage.setItem('clientSession', JSON.stringify(newClient));
          setCurrentClient(newClient);
          setClientData({ name: newClient.name, phone: newClient.phone, birthDate: '' });
      } else {
          // Login
          const clients = storage.getClients();
          const client = clients.find(c => c.phone === phone && c.password === password);
          if (client) {
              sessionStorage.setItem('clientSession', JSON.stringify(client));
              setCurrentClient(client);
              setClientData({ name: client.name, phone: client.phone, birthDate: client.birthDate || '' });
          } else {
              alert('Credenciais inválidas.');
              return;
          }
      }
      setShowLoginModal(false);
  };

  const handleLogout = () => {
      sessionStorage.removeItem('clientSession');
      setCurrentClient(null);
      setClientData({ name: '', phone: '', birthDate: '' });
      setShowProfileModal(false);
  };

  // Helper to format currency
  const formatMoney = (val: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  // Render Functions for Steps
  const renderServices = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {services.map(service => (
        <div 
          key={service.id}
          onClick={() => { setSelectedService(service); handleNext(); }}
          className="bg-zinc-900 border border-zinc-800 p-5 rounded-xl cursor-pointer hover:border-amber-500 hover:bg-zinc-800 transition-all group"
        >
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-lg font-semibold text-zinc-100 group-hover:text-amber-500">{service.name}</h3>
            <span className="font-bold text-amber-500">{formatMoney(service.price)}</span>
          </div>
          <p className="text-zinc-400 text-sm mb-3">{service.description}</p>
          <div className="flex items-center justify-between text-xs text-zinc-500">
            <div className="flex items-center">
                <Clock size={14} className="mr-1" />
                {service.durationMinutes} min
            </div>
            {service.type === 'subscription' && (
                <span className="bg-purple-500/20 text-purple-400 px-2 py-0.5 rounded-full">Assinatura</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );

  const renderBarbers = () => (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
      {barbers.map(barber => (
        <div 
          key={barber.id}
          onClick={() => { setSelectedBarber(barber); handleNext(); }}
          className="bg-zinc-900 border border-zinc-800 p-6 rounded-xl cursor-pointer hover:border-amber-500 hover:bg-zinc-800 transition-all flex flex-col items-center text-center group"
        >
          <img 
            src={barber.photoUrl} 
            alt={barber.name} 
            className="w-24 h-24 rounded-full object-cover mb-4 border-2 border-zinc-700 group-hover:border-amber-500"
          />
          <h3 className="text-lg font-semibold text-zinc-100">{barber.name}</h3>
          <p className="text-sm text-zinc-500">Profissional</p>
        </div>
      ))}
    </div>
  );

  const renderDateTime = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-zinc-400 mb-2">Selecione a Data</label>
        <input 
          type="date" 
          min={new Date().toISOString().split('T')[0]}
          value={selectedDate}
          onChange={(e) => { setSelectedDate(e.target.value); setSelectedTime(''); }}
          className="w-full bg-zinc-900 border border-zinc-800 text-zinc-100 rounded-lg p-3 focus:outline-none focus:border-amber-500"
        />
      </div>
      
      {selectedDate && (
        <div>
          <label className="block text-zinc-400 mb-2">Horários Disponíveis</label>
          {timeSlots.length === 0 ? (
            <p className="text-red-400 text-sm">Não há horários disponíveis nesta data.</p>
          ) : (
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
              {timeSlots.map(time => (
                <button
                  key={time}
                  onClick={() => setSelectedTime(time)}
                  className={`py-2 px-3 rounded-lg text-sm font-medium transition-all ${
                    selectedTime === time 
                      ? 'bg-amber-500 text-zinc-900' 
                      : 'bg-zinc-900 border border-zinc-800 text-zinc-300 hover:border-zinc-600'
                  }`}
                >
                  {time}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      <button 
        disabled={!selectedDate || !selectedTime}
        onClick={handleNext}
        className="w-full mt-6 bg-zinc-100 text-zinc-900 py-3 rounded-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-white transition-colors"
      >
        Continuar
      </button>
    </div>
  );

  const renderForm = () => (
    <div className="max-w-md mx-auto space-y-4">
      {!currentClient && (
          <div className="bg-blue-500/10 border border-blue-500/20 p-4 rounded-lg mb-4 flex items-center justify-between">
              <div className="text-sm text-blue-200">
                  Tem conta? Faça login para ganhar XP!
              </div>
              <button 
                onClick={() => setShowLoginModal(true)}
                className="text-xs bg-blue-500 text-white px-3 py-2 rounded-lg font-bold hover:bg-blue-600"
              >
                  Entrar
              </button>
          </div>
      )}

      <div>
        <label className="block text-zinc-400 text-sm mb-1">Nome Completo</label>
        <input 
          type="text" 
          value={clientData.name}
          onChange={e => setClientData({...clientData, name: e.target.value})}
          className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-3 text-white focus:border-amber-500 focus:outline-none"
          placeholder="Seu nome"
          readOnly={!!currentClient} // Read only if logged in
        />
      </div>
      <div>
        <label className="block text-zinc-400 text-sm mb-1">Telefone / WhatsApp</label>
        <input 
          type="tel" 
          value={clientData.phone}
          onChange={e => setClientData({...clientData, phone: e.target.value})}
          className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-3 text-white focus:border-amber-500 focus:outline-none"
          placeholder="(11) 99999-9999"
          readOnly={!!currentClient} // Read only if logged in
        />
      </div>
      <div>
        <label className="block text-zinc-400 text-sm mb-1">Data de Nascimento (Opcional)</label>
        <input 
          type="date" 
          value={clientData.birthDate}
          onChange={e => setClientData({...clientData, birthDate: e.target.value})}
          className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-3 text-white focus:border-amber-500 focus:outline-none"
        />
      </div>

      <div className="bg-zinc-900 p-4 rounded-lg border border-zinc-800 mt-6">
        <h4 className="text-zinc-400 text-xs uppercase tracking-wider mb-3">Resumo</h4>
        <div className="flex justify-between mb-2">
          <span className="text-zinc-300">{selectedService?.name}</span>
          <span className="text-zinc-100">{selectedService && formatMoney(selectedService.price)}</span>
        </div>
        <div className="flex justify-between text-sm text-zinc-500">
          <span>Profissional:</span>
          <span>{selectedBarber?.name}</span>
        </div>
        <div className="flex justify-between text-sm text-zinc-500">
          <span>Data:</span>
          <span>{selectedDate} às {selectedTime}</span>
        </div>
      </div>
        
      {currentClient && (
          <div className="text-center text-sm text-yellow-500 font-bold flex items-center justify-center gap-2 mt-2">
              <Trophy size={16}/> Ganhe +{levelConfig.xpPerService} XP ao concluir!
          </div>
      )}

      <button 
        disabled={!clientData.name || !clientData.phone}
        onClick={handleSubmit}
        className="w-full mt-4 bg-amber-500 text-zinc-900 py-3 rounded-lg font-bold hover:bg-amber-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Confirmar Agendamento
      </button>
    </div>
  );

  const renderSuccess = () => (
    <div className="text-center py-12">
      <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
        <CheckCircle className="text-green-500 w-10 h-10" />
      </div>
      <h2 className="text-2xl font-bold text-white mb-2">Agendamento Confirmado!</h2>
      <p className="text-zinc-400 mb-8">Te esperamos no dia e horário marcado.</p>
      
      <button 
        onClick={() => {
            setCurrentStep(0);
            setSelectedDate('');
            setSelectedTime('');
            // Keep client data if logged in
            if(!currentClient) setClientData({ name: '', phone: '', birthDate: '' });
        }}
        className="text-amber-500 hover:text-amber-400 font-medium"
      >
        Fazer novo agendamento
      </button>
    </div>
  );

  // --- Profile Logic ---
  const currentLvlIdx = (currentClient?.level || 1) - 1;
  const nextLvlIdx = Math.min(LEVEL_NAMES.length - 1, currentLvlIdx + 1);
  const nextLvlXp = levelConfig.levels[currentLvlIdx] || 99999;
  const prevLvlXp = currentLvlIdx > 0 ? levelConfig.levels[currentLvlIdx - 1] : 0;
  
  // Calculate Progress in current level only
  const xpInLevel = (currentClient?.xp || 0) - prevLvlXp;
  const xpNeeded = nextLvlXp - prevLvlXp;
  const xpProgress = Math.min(100, Math.max(0, (xpInLevel / xpNeeded) * 100));
  
  const borderColor = currentClient ? BORDER_COLORS[currentLvlIdx] : 'border-zinc-700';
  const nextBorderColor = currentClient ? BORDER_COLORS[nextLvlIdx] : 'border-zinc-700';
  const levelName = currentClient ? LEVEL_NAMES[currentLvlIdx] : 'Iniciante';

  // --- Profile Modal Logic ---
  const [activeTab, setActiveTab] = useState<'overview' | 'edit' | 'history' | 'refer'>('overview');
  const [editForm, setEditForm] = useState({ name: '', phone: '' });
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
      if (currentClient && showProfileModal) {
          setEditForm({ name: currentClient.name, phone: currentClient.phone });
      }
  }, [currentClient, showProfileModal]);

  const handleUpdateProfile = (e: React.FormEvent) => {
      e.preventDefault();
      if (!currentClient) return;
      const updated = { ...currentClient, ...editForm };
      storage.updateClient(updated);
      setCurrentClient(updated);
      alert('Perfil atualizado!');
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file || !currentClient) return;
      
      const reader = new FileReader();
      reader.onloadend = () => {
          const base64 = reader.result as string;
          const updated = { ...currentClient, photoUrl: base64 };
          storage.updateClient(updated);
          setCurrentClient(updated);
      };
      reader.readAsDataURL(file);
  };

  const myHistory = useMemo(() => {
      if (!currentClient) return [];
      const allApps = storage.getAppointments();
      return allApps
        .filter(a => a.clientId === currentClient.id)
        .sort((a, b) => new Date(b.date + 'T' + b.time).getTime() - new Date(a.date + 'T' + a.time).getTime());
  }, [currentClient, showProfileModal]);

  const referralLink = currentClient ? `${window.location.origin}/#/?ref=${currentClient.id}` : '';

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col">
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-md sticky top-0 z-20">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-amber-500 rounded flex items-center justify-center text-zinc-900 font-bold">B</div>
            <h1 className="font-bold text-xl tracking-tight hidden sm:block">BarberPro</h1>
          </div>

          <div className="flex items-center gap-4">
              {currentClient ? (
                  <div 
                    onClick={() => setShowProfileModal(true)}
                    className="flex items-center gap-3 bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 cursor-pointer rounded-full pr-1 pl-4 py-1 transition-colors"
                  >
                      <div className="flex flex-col items-end">
                          <span className="text-xs font-bold text-white leading-none">{currentClient.name.split(' ')[0]}</span>
                          <span className="text-[10px] text-amber-500 font-bold uppercase tracking-wider">{levelName}</span>
                      </div>
                      
                      {/* Profile Picture with Dynamic Border */}
                      <div className={`relative w-8 h-8 rounded-full border-2 ${borderColor} p-0.5`}>
                           {currentClient.photoUrl ? (
                               <img src={currentClient.photoUrl} className="w-full h-full rounded-full object-cover" />
                           ) : (
                               <div className="w-full h-full bg-zinc-800 rounded-full flex items-center justify-center overflow-hidden">
                                    <User size={16} className="text-zinc-400"/>
                               </div>
                           )}
                      </div>
                  </div>
              ) : (
                <button 
                    onClick={() => { setIsRegistering(false); setShowLoginModal(true); }}
                    className="text-sm text-zinc-300 hover:text-white font-medium flex items-center gap-2 bg-zinc-800 px-3 py-1.5 rounded-lg border border-zinc-700"
                >
                    <User size={16}/> Entrar
                </button>
              )}
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {currentStep < 4 && (
             <div className="mb-8">
               <div className="flex justify-between mb-4">
                  {STEPS.slice(0, 4).map((step, idx) => (
                    <div key={idx} className={`flex flex-col items-center ${idx <= currentStep ? 'opacity-100' : 'opacity-40'}`}>
                       <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold mb-2 transition-colors ${
                         idx === currentStep ? 'bg-amber-500 text-zinc-900' : 
                         idx < currentStep ? 'bg-green-500 text-zinc-900' : 'bg-zinc-800 text-zinc-400'
                       }`}>
                         {idx < currentStep ? <CheckCircle size={14} /> : idx + 1}
                       </div>
                       <span className="text-xs hidden sm:block">{step}</span>
                    </div>
                  ))}
               </div>
               <div className="h-1 bg-zinc-800 rounded-full overflow-hidden">
                 <div 
                  className="h-full bg-amber-500 transition-all duration-300"
                  style={{ width: `${((currentStep) / 3) * 100}%` }}
                 />
               </div>
             </div>
          )}

          <div className="bg-zinc-900/30 border border-zinc-800/50 rounded-2xl p-6 sm:p-8 min-h-[400px]">
            {currentStep > 0 && currentStep < 4 && (
              <button onClick={handleBack} className="mb-6 flex items-center text-zinc-500 hover:text-zinc-300">
                <ArrowLeft size={16} className="mr-1" /> Voltar
              </button>
            )}

            <h2 className="text-2xl font-bold mb-6 text-center sm:text-left">
              {STEPS[currentStep]}
            </h2>

            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
              {currentStep === 0 && renderServices()}
              {currentStep === 1 && renderBarbers()}
              {currentStep === 2 && renderDateTime()}
              {currentStep === 3 && renderForm()}
              {currentStep === 4 && renderSuccess()}
            </div>
          </div>
        </div>
      </main>
      
      {/* Footer / Login Link for Admin */}
      <footer className="py-6 text-center text-zinc-600 text-sm border-t border-zinc-900 flex flex-col items-center gap-2">
        <p>© 2024 BarberPro System. Todos os direitos reservados.</p>
        <Link to="/admin/login" className="text-xs text-zinc-700 hover:text-zinc-500">Área do Profissional</Link>
      </footer>

      {/* LOGIN / REGISTER MODAL */}
      {showLoginModal && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
               <div className="bg-zinc-900 border border-zinc-700 w-full max-w-sm rounded-2xl p-6 shadow-2xl animate-in zoom-in-95 duration-200">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-xl font-bold text-white">{isRegistering ? 'Criar Conta' : 'Entrar'}</h3>
                        <button onClick={() => setShowLoginModal(false)} className="text-zinc-500 hover:text-white"><X/></button>
                    </div>

                    <form onSubmit={handleAuthSubmit} className="space-y-4">
                        {isRegistering && (
                            <div>
                                <label className="text-xs text-zinc-400 uppercase font-bold">Nome Completo</label>
                                <input name="name" required className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-white mt-1 outline-none focus:border-amber-500" placeholder="Seu nome"/>
                            </div>
                        )}
                        <div>
                            <label className="text-xs text-zinc-400 uppercase font-bold">Telefone (Login)</label>
                            <input name="phone" required className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-white mt-1 outline-none focus:border-amber-500" placeholder="(11) 99999-9999"/>
                        </div>
                        <div>
                            <label className="text-xs text-zinc-400 uppercase font-bold">Senha / PIN</label>
                            <input name="password" type="password" required className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-white mt-1 outline-none focus:border-amber-500" placeholder="****"/>
                        </div>

                        <button className="w-full bg-amber-500 hover:bg-amber-400 text-zinc-900 font-bold py-3 rounded-xl transition-colors">
                            {isRegistering ? 'Cadastrar e Entrar' : 'Entrar'}
                        </button>
                    </form>

                    <div className="mt-4 text-center">
                        <button 
                            onClick={() => setIsRegistering(!isRegistering)}
                            className="text-sm text-zinc-400 hover:text-white underline"
                        >
                            {isRegistering ? 'Já tem conta? Faça Login' : 'Não tem conta? Cadastre-se'}
                        </button>
                    </div>
               </div>
          </div>
      )}

      {/* FULL PROFILE MODAL */}
      {showProfileModal && currentClient && (
          <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-0 sm:p-4 backdrop-blur-sm">
             <div className="bg-zinc-900 w-full h-full sm:h-auto sm:max-w-2xl sm:rounded-2xl flex flex-col overflow-hidden relative">
                 
                 {/* Header */}
                 <div className="p-4 border-b border-zinc-800 flex justify-between items-center bg-zinc-900 z-10">
                     <h3 className="text-lg font-bold text-white flex items-center gap-2"><User size={20}/> Meu Perfil</h3>
                     <button onClick={() => setShowProfileModal(false)} className="p-2 bg-zinc-800 rounded-full text-zinc-400 hover:text-white"><X size={20}/></button>
                 </div>

                 {/* Scrollable Content */}
                 <div className="flex-1 overflow-y-auto">
                     {/* Top Section: Photo & Level */}
                     <div className="p-6 flex flex-col items-center bg-gradient-to-b from-zinc-800/50 to-zinc-900 border-b border-zinc-800">
                         <div className="relative group mb-4">
                             <div className={`w-24 h-24 rounded-full border-4 ${borderColor} p-1 relative`}>
                                 {currentClient.photoUrl ? (
                                     <img src={currentClient.photoUrl} className="w-full h-full rounded-full object-cover" />
                                 ) : (
                                     <div className="w-full h-full bg-zinc-800 rounded-full flex items-center justify-center"><User size={40} className="text-zinc-500"/></div>
                                 )}
                             </div>
                             <button 
                                onClick={() => fileInputRef.current?.click()}
                                className="absolute bottom-0 right-0 bg-amber-500 text-zinc-900 p-2 rounded-full border-4 border-zinc-900 hover:bg-amber-400 transition-transform hover:scale-110"
                             >
                                 <Camera size={14}/>
                             </button>
                             <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handlePhotoUpload}/>
                         </div>

                         <h2 className="text-2xl font-bold text-white">{currentClient.name}</h2>
                         <p className="text-zinc-500 text-sm mb-4">{currentClient.phone}</p>

                         {/* Tabs */}
                         <div className="flex gap-2 bg-zinc-950 p-1 rounded-lg border border-zinc-800 w-full max-w-sm">
                             <button onClick={() => setActiveTab('overview')} className={`flex-1 py-2 text-xs font-bold rounded-md transition-colors ${activeTab === 'overview' ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}>Início</button>
                             <button onClick={() => setActiveTab('edit')} className={`flex-1 py-2 text-xs font-bold rounded-md transition-colors ${activeTab === 'edit' ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}>Editar</button>
                             <button onClick={() => setActiveTab('history')} className={`flex-1 py-2 text-xs font-bold rounded-md transition-colors ${activeTab === 'history' ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}>Histórico</button>
                             <button onClick={() => setActiveTab('refer')} className={`flex-1 py-2 text-xs font-bold rounded-md transition-colors ${activeTab === 'refer' ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}>Indique</button>
                         </div>
                     </div>

                     <div className="p-6">
                        {/* TAB: OVERVIEW */}
                        {activeTab === 'overview' && (
                            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
                                {/* Level Progress */}
                                <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-5 relative overflow-hidden">
                                     <div className="flex justify-between items-center mb-6 z-10 relative">
                                         {/* Current Level */}
                                         <div className="flex flex-col items-center gap-2">
                                             <div className={`w-12 h-12 rounded-full border-2 ${borderColor} flex items-center justify-center font-bold text-xl text-white bg-zinc-900`}>
                                                 {currentClient.level}
                                             </div>
                                             <span className="text-xs text-zinc-500 uppercase font-bold">{levelName}</span>
                                         </div>

                                         {/* Arrow / Progress */}
                                         <div className="flex-1 px-4 flex flex-col items-center">
                                             <span className="text-amber-500 font-bold text-lg mb-1">
                                                 {xpInLevel} / {xpNeeded} XP
                                             </span>
                                             <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                                                 <div className="h-full bg-amber-500 transition-all duration-1000" style={{width: `${xpProgress}%`}}></div>
                                             </div>
                                             <p className="text-[10px] text-zinc-600 mt-2">Faltam {xpNeeded - xpInLevel} XP para subir</p>
                                         </div>

                                         {/* Next Level */}
                                         <div className="flex flex-col items-center gap-2 opacity-50">
                                             <div className={`w-12 h-12 rounded-full border-2 ${nextBorderColor} flex items-center justify-center font-bold text-xl text-white bg-zinc-900`}>
                                                 {currentClient.level + 1}
                                             </div>
                                             <span className="text-xs text-zinc-500 uppercase font-bold">{LEVEL_NAMES[nextLvlIdx]}</span>
                                         </div>
                                     </div>
                                </div>
                                
                                <div className="grid grid-cols-2 gap-4">
                                     <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 flex flex-col items-center justify-center text-center">
                                         <Scissors className="text-blue-500 mb-2" size={24}/>
                                         <span className="text-2xl font-bold text-white">{currentClient.totalAppointments}</span>
                                         <span className="text-xs text-zinc-500">Agendamentos</span>
                                     </div>
                                     <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 flex flex-col items-center justify-center text-center">
                                         <Share2 className="text-green-500 mb-2" size={24}/>
                                         <span className="text-2xl font-bold text-white">{currentClient.referralCount || 0}</span>
                                         <span className="text-xs text-zinc-500">Amigos Indicados</span>
                                     </div>
                                </div>
                            </div>
                        )}

                        {/* TAB: EDIT PROFILE */}
                        {activeTab === 'edit' && (
                            <form onSubmit={handleUpdateProfile} className="space-y-4 animate-in fade-in slide-in-from-bottom-2">
                                <div>
                                    <label className="text-xs text-zinc-500 uppercase font-bold">Nome Completo</label>
                                    <input 
                                        type="text" 
                                        value={editForm.name}
                                        onChange={e => setEditForm({...editForm, name: e.target.value})}
                                        className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-white mt-1 focus:border-amber-500 outline-none"
                                    />
                                </div>
                                <div>
                                    <label className="text-xs text-zinc-500 uppercase font-bold">Telefone</label>
                                    <input 
                                        type="text" 
                                        value={editForm.phone}
                                        onChange={e => setEditForm({...editForm, phone: e.target.value})}
                                        className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-white mt-1 focus:border-amber-500 outline-none"
                                    />
                                </div>
                                <button className="w-full bg-zinc-800 hover:bg-zinc-700 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-colors">
                                    <Edit3 size={18}/> Salvar Alterações
                                </button>
                                
                                <div className="pt-4 border-t border-zinc-800">
                                    <button 
                                        type="button" 
                                        onClick={handleLogout} 
                                        className="w-full text-red-500 text-sm font-medium hover:bg-red-500/10 p-3 rounded-lg flex items-center justify-center gap-2"
                                    >
                                        <LogOut size={16}/> Sair da Conta
                                    </button>
                                </div>
                            </form>
                        )}

                        {/* TAB: HISTORY */}
                        {activeTab === 'history' && (
                            <div className="space-y-3 animate-in fade-in slide-in-from-bottom-2">
                                {myHistory.length === 0 ? (
                                    <div className="text-center py-8 text-zinc-500">
                                        <History size={32} className="mx-auto mb-2 opacity-50"/>
                                        <p>Nenhum agendamento encontrado.</p>
                                    </div>
                                ) : (
                                    myHistory.map(app => {
                                        const srv = services.find(s => s.id === app.serviceId);
                                        const brb = barbers.find(b => b.id === app.barberId);
                                        return (
                                            <div key={app.id} className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex justify-between items-center">
                                                <div>
                                                    <h4 className="font-bold text-white text-sm">{srv?.name}</h4>
                                                    <p className="text-xs text-zinc-500">{new Date(app.date).toLocaleDateString('pt-BR')} às {app.time}</p>
                                                    <p className="text-[10px] text-zinc-600">com {brb?.name}</p>
                                                </div>
                                                <div className="text-right">
                                                    <span className={`text-xs font-bold px-2 py-1 rounded ${
                                                        app.status === 'completed' ? 'bg-green-500/10 text-green-500' : 
                                                        app.status === 'cancelled' ? 'bg-red-500/10 text-red-500' : 
                                                        'bg-amber-500/10 text-amber-500'
                                                    }`}>
                                                        {app.status === 'completed' ? 'Concluído' : app.status === 'cancelled' ? 'Cancelado' : 'Agendado'}
                                                    </span>
                                                    {app.status === 'completed' && (
                                                        <div className="text-[10px] text-green-600 mt-1 flex items-center justify-end gap-1">
                                                            +{levelConfig.xpPerService} XP
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        );
                                    })
                                )}
                            </div>
                        )}

                         {/* TAB: REFER */}
                         {activeTab === 'refer' && (
                             <div className="space-y-6 text-center animate-in fade-in slide-in-from-bottom-2">
                                 <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center mx-auto shadow-lg shadow-purple-500/20">
                                     <Share2 className="text-white" size={32}/>
                                 </div>
                                 <div>
                                     <h3 className="text-xl font-bold text-white">Indique e Ganhe!</h3>
                                     <p className="text-sm text-zinc-400 mt-2">
                                         Convide amigos para a BarberPro. Quando eles se cadastrarem usando seu link, você ganha pontos no ranking de indicações!
                                     </p>
                                 </div>

                                 <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-xl">
                                     <label className="text-xs text-zinc-500 uppercase font-bold block mb-2 text-left">Seu Link de Convite</label>
                                     <div className="flex gap-2">
                                         <input 
                                            readOnly 
                                            value={referralLink}
                                            className="w-full bg-zinc-900 border border-zinc-700 rounded p-2 text-zinc-300 text-xs"
                                         />
                                         <button 
                                            onClick={() => {
                                                navigator.clipboard.writeText(referralLink);
                                                alert('Link copiado!');
                                            }}
                                            className="bg-zinc-800 text-white p-2 rounded hover:bg-zinc-700"
                                         >
                                             <Copy size={16}/>
                                         </button>
                                     </div>
                                 </div>
                                 
                                 <div className="p-4 bg-green-500/10 rounded-xl border border-green-500/20">
                                     <p className="text-green-400 font-bold text-lg">{currentClient.referralCount || 0}</p>
                                     <p className="text-xs text-green-600/70 uppercase font-bold">Amigos cadastrados</p>
                                 </div>
                             </div>
                         )}

                     </div>
                 </div>
             </div>
          </div>
      )}

    </div>
  );
};

export default BookingPage;