import React, { useMemo } from 'react';
import { storage } from '../../utils/storage';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { DollarSign, Calendar, Users, TrendingUp, Scissors, Package, Crown, ChevronRight } from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const role = sessionStorage.getItem('userRole');
  const userId = sessionStorage.getItem('userId');
  const isAdmin = role === 'ADMIN';

  const appointments = storage.getAppointments();
  const services = storage.getServices();
  const allBarbers = storage.getBarbers();

  // --- Helpers for Date Logic ---
  const isToday = (dateString: string) => {
    const today = new Date();
    const d = new Date(dateString + 'T00:00:00'); // Fix timezone offset issues
    return d.getDate() === today.getDate() &&
           d.getMonth() === today.getMonth() &&
           d.getFullYear() === today.getFullYear();
  };

  const isThisWeek = (dateString: string) => {
    const d = new Date(dateString + 'T00:00:00');
    const today = new Date();
    const firstDay = new Date(today.setDate(today.getDate() - today.getDay()));
    const lastDay = new Date(today.setDate(today.getDate() - today.getDay() + 6));
    return d >= firstDay && d <= lastDay;
  };

  const isThisMonth = (dateString: string) => {
    const today = new Date();
    const d = new Date(dateString + 'T00:00:00');
    return d.getMonth() === today.getMonth() && d.getFullYear() === today.getFullYear();
  };

  const stats = useMemo(() => {
    // 1. FILTER DATA BASED ON ROLE
    // If Admin, use all. If Barber, filter everything by userId.
    let relevantApps = appointments;
    let relevantBarbers = allBarbers;

    if (!isAdmin && userId) {
        relevantApps = appointments.filter(a => a.barberId === userId);
        relevantBarbers = allBarbers.filter(b => b.id === userId);
    }

    // Only consider completed/paid appointments for revenue
    const completedApps = relevantApps.filter(a => a.status === 'completed');
    // Consider pending+confirmed+completed for appointment counts
    const allActiveApps = relevantApps.filter(a => a.status !== 'cancelled' && a.status !== 'blocked');

    // 2. Revenue Today & Breakdown
    const todayApps = completedApps.filter(a => isToday(a.date));
    const revenueTodayTotal = todayApps.reduce((acc, curr) => acc + (curr.finalPrice ?? curr.totalPrice), 0);
    
    // For admin, breakdown by barber. For barber, it's just them.
    const revenueTodayByBarber = relevantBarbers.map(b => {
      const bApps = todayApps.filter(a => a.barberId === b.id);
      const total = bApps.reduce((acc, curr) => acc + (curr.finalPrice ?? curr.totalPrice), 0);
      return { id: b.id, name: b.name, total };
    }).sort((a, b) => b.total - a.total);

    // 3. Appointment Counts (Volume)
    const countToday = allActiveApps.filter(a => isToday(a.date)).length;
    const countWeek = allActiveApps.filter(a => isThisWeek(a.date)).length;
    const countMonth = allActiveApps.filter(a => isThisMonth(a.date)).length;

    const countMonthByBarber = relevantBarbers.map(b => {
      const count = allActiveApps.filter(a => a.barberId === b.id && isThisMonth(a.date)).length;
      return { id: b.id, name: b.name, count };
    }).sort((a, b) => b.count - a.count);

    // 4. Revenue Sources (Based on filtered apps)
    const revenueSources = {
      service: 0,
      product: 0,
      subscription: 0
    };
    
    completedApps.forEach(app => {
      const service = services.find(s => s.id === app.serviceId);
      const val = app.finalPrice ?? app.totalPrice;
      if (service?.type) {
        revenueSources[service.type] += val;
      }
    });

    const sourceData = [
      { name: 'Serviços', value: revenueSources.service, color: '#f59e0b' },
      { name: 'Produtos', value: revenueSources.product, color: '#10b981' },
      { name: 'Assinaturas', value: revenueSources.subscription, color: '#8b5cf6' },
    ];

    const totalRevenueAllTime = revenueSources.service + revenueSources.product + revenueSources.subscription;

    // 5. Monthly Commissions Calculation
    const monthlyCommissions = relevantBarbers.filter(b => b.active).map(b => {
        // Filter completed apps for this barber in this month
        // (Note: relevantApps is already filtered by barber if !isAdmin, but good to be explicit here)
        const bAppsMonth = completedApps.filter(a => a.barberId === b.id && isThisMonth(a.date));
        
        let totalCommission = 0;
        let totalSales = 0;

        // Breakdown for Barber View
        const breakdown = { service: 0, product: 0, subscription: 0 };

        bAppsMonth.forEach(app => {
            const service = services.find(s => s.id === app.serviceId);
            const price = app.finalPrice ?? app.totalPrice;
            totalSales += price;

            const type = service?.type || 'service';
            
            // Commission Logic
            const barberCategoryRate = b.commissionRates ? b.commissionRates[type] : 0;
            const rate = (service?.commissionRate !== undefined && service.commissionRate !== null) 
                         ? service.commissionRate 
                         : barberCategoryRate;
            
            const commVal = (price * rate) / 100;
            totalCommission += commVal;
            breakdown[type] += commVal;
        });

        return {
            ...b,
            monthSales: totalSales,
            monthCommission: totalCommission,
            breakdown,
            appsCount: bAppsMonth.length
        };
    });

    return {
      revenueTodayTotal,
      revenueTodayByBarber,
      countToday,
      countWeek,
      countMonth,
      countMonthByBarber,
      sourceData,
      totalRevenueAllTime,
      monthlyCommissions
    };
  }, [appointments, allBarbers, services, isAdmin, userId]);

  const formatMoney = (val: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  return (
    <div className="space-y-6 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 className="text-3xl font-bold text-white">Dashboard</h1>
            <p className="text-zinc-400 text-sm">Visão geral de {new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}</p>
        </div>
      </div>

      {/* Row 1: Revenue Today & Appointments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Card 1: Revenue Today */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 flex flex-col h-full shadow-lg">
           <div className="flex justify-between items-start mb-4">
              <div>
                 <p className="text-zinc-400 font-medium text-sm uppercase tracking-wide">Faturamento Hoje</p>
                 <h2 className="text-4xl font-bold text-white mt-1">{formatMoney(stats.revenueTodayTotal)}</h2>
              </div>
              <div className="p-3 bg-green-500/10 rounded-xl text-green-500">
                  <DollarSign size={24} />
              </div>
           </div>
           
           <div className="flex-1 bg-zinc-950/50 rounded-lg p-3 border border-zinc-800/50">
              <p className="text-xs text-zinc-500 font-bold mb-2 uppercase">
                  {isAdmin ? 'Por Profissional (Hoje)' : 'Seu Desempenho (Hoje)'}
              </p>
              <div className="space-y-2 max-h-[120px] overflow-y-auto pr-1 custom-scrollbar">
                  {stats.revenueTodayByBarber.map(b => (
                      <div key={b.id} className="flex justify-between items-center text-sm">
                          <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-green-500"></div>
                              <span className="text-zinc-300">{b.name}</span>
                          </div>
                          <span className="text-white font-mono">{formatMoney(b.total)}</span>
                      </div>
                  ))}
                  {stats.revenueTodayByBarber.length === 0 && <p className="text-zinc-600 text-xs italic">Nenhum faturamento hoje.</p>}
              </div>
           </div>
        </div>

        {/* Card 2: Appointments */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 flex flex-col h-full shadow-lg">
           <div className="flex justify-between items-start mb-4">
              <div>
                 <p className="text-zinc-400 font-medium text-sm uppercase tracking-wide">Agendamentos</p>
                 <div className="flex gap-4 mt-2">
                     <div>
                         <span className="text-2xl font-bold text-white block">{stats.countToday}</span>
                         <span className="text-xs text-zinc-500">Hoje</span>
                     </div>
                     <div className="w-px bg-zinc-800"></div>
                     <div>
                         <span className="text-2xl font-bold text-white block">{stats.countWeek}</span>
                         <span className="text-xs text-zinc-500">Semana</span>
                     </div>
                     <div className="w-px bg-zinc-800"></div>
                     <div>
                         <span className="text-2xl font-bold text-amber-500 block">{stats.countMonth}</span>
                         <span className="text-xs text-zinc-500">Mês</span>
                     </div>
                 </div>
              </div>
              <div className="p-3 bg-blue-500/10 rounded-xl text-blue-500">
                  <Calendar size={24} />
              </div>
           </div>

           <div className="flex-1 bg-zinc-950/50 rounded-lg p-3 border border-zinc-800/50">
              <p className="text-xs text-zinc-500 font-bold mb-2 uppercase">
                   {isAdmin ? 'Total por Profissional (Mês)' : 'Seus Atendimentos (Mês)'}
              </p>
              <div className="space-y-2 max-h-[120px] overflow-y-auto pr-1 custom-scrollbar">
                  {stats.countMonthByBarber.map(b => (
                      <div key={b.id} className="flex justify-between items-center text-sm">
                          <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                              <span className="text-zinc-300">{b.name}</span>
                          </div>
                          <span className="text-white font-mono">{b.count}</span>
                      </div>
                  ))}
              </div>
           </div>
        </div>
      </div>

      {/* Row 2: Revenue Sources & Commissions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Revenue Sources Chart */}
          <div className="lg:col-span-1 bg-zinc-900 border border-zinc-800 rounded-xl p-5 flex flex-col">
              <h3 className="text-white font-bold mb-1 flex items-center gap-2">
                  <TrendingUp size={18} className="text-amber-500"/> Fontes de Receita
              </h3>
              <p className="text-xs text-zinc-500 mb-4">
                  {isAdmin ? 'Total histórico acumulado' : 'Seu total histórico acumulado'}
              </p>
              
              <div className="h-[200px] w-full relative">
                 <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                            data={stats.sourceData}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                        >
                            {stats.sourceData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} stroke="rgba(0,0,0,0)"/>
                            ))}
                        </Pie>
                        <Tooltip 
                            formatter={(value: number) => formatMoney(value)}
                            contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', borderRadius: '8px', color: '#fff' }}
                            itemStyle={{ color: '#fff' }}
                        />
                    </PieChart>
                 </ResponsiveContainer>
                 {/* Center Total */}
                 <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                     <span className="text-xs font-bold text-zinc-400">Total</span>
                 </div>
              </div>

              <div className="mt-4 space-y-3">
                  {stats.sourceData.map((item) => (
                      <div key={item.name} className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2">
                              <div className="w-3 h-3 rounded-full" style={{backgroundColor: item.color}}></div>
                              <span className="text-zinc-300 flex items-center gap-1">
                                  {item.name === 'Serviços' && <Scissors size={12}/>}
                                  {item.name === 'Produtos' && <Package size={12}/>}
                                  {item.name === 'Assinaturas' && <Crown size={12}/>}
                                  {item.name}
                              </span>
                          </div>
                          <span className="font-mono text-white">{formatMoney(item.value)}</span>
                      </div>
                  ))}
                  <div className="pt-3 border-t border-zinc-800 flex justify-between font-bold text-white">
                      <span>Total Geral</span>
                      <span>{formatMoney(stats.totalRevenueAllTime)}</span>
                  </div>
              </div>
          </div>

          {/* Active Professionals & Commissions Table */}
          <div className="lg:col-span-2 bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden flex flex-col">
              <div className="p-5 border-b border-zinc-800 bg-zinc-900">
                  <h3 className="text-white font-bold text-lg flex items-center gap-2">
                      <Users size={20} className="text-amber-500"/> 
                      {isAdmin ? 'Comissões do Mês (Geral)' : 'Suas Comissões (Mês)'}
                  </h3>
                  <p className="text-xs text-zinc-500 mt-1">
                      Cálculo automático baseado nos recebimentos de {new Date().toLocaleDateString('pt-BR', { month: 'long' })}.
                  </p>
              </div>

              <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                      <thead>
                          <tr className="bg-zinc-950/50 text-xs uppercase text-zinc-500 border-b border-zinc-800">
                              <th className="p-4 font-bold">Profissional</th>
                              <th className="p-4 font-bold text-center">Atendimentos</th>
                              <th className="p-4 font-bold text-right">Vendas (Mês)</th>
                              {!isAdmin && <th className="p-4 font-bold text-right">Detalhamento</th>}
                              <th className="p-4 font-bold text-right text-amber-500">Comissão Total</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-zinc-800 text-sm">
                          {stats.monthlyCommissions.map((barber) => (
                              <tr key={barber.id} className="hover:bg-zinc-800/30 transition-colors">
                                  <td className="p-4">
                                      <div className="flex items-center gap-3">
                                          <img src={barber.photoUrl} alt="" className="w-10 h-10 rounded-full border border-zinc-700 object-cover"/>
                                          <div>
                                              <p className="font-bold text-white">{barber.name}</p>
                                              {isAdmin && (
                                                <div className="flex gap-2 text-[10px] text-zinc-500 mt-0.5">
                                                    <span>S:{barber.commissionRates?.service}%</span>
                                                    <span>A:{barber.commissionRates?.subscription}%</span>
                                                    <span>P:{barber.commissionRates?.product}%</span>
                                                </div>
                                              )}
                                          </div>
                                      </div>
                                  </td>
                                  <td className="p-4 text-center">
                                      <span className="bg-zinc-800 text-zinc-300 px-2 py-1 rounded text-xs font-bold">
                                          {barber.appsCount}
                                      </span>
                                  </td>
                                  <td className="p-4 text-right text-zinc-400 font-mono">
                                      {formatMoney(barber.monthSales)}
                                  </td>
                                  
                                  {!isAdmin && (
                                      <td className="p-4 text-right">
                                          <div className="flex flex-col text-xs text-zinc-500">
                                              <span className="flex justify-end gap-1">S: <span className="text-zinc-300">{formatMoney(barber.breakdown.service)}</span></span>
                                              <span className="flex justify-end gap-1">A: <span className="text-zinc-300">{formatMoney(barber.breakdown.subscription)}</span></span>
                                              <span className="flex justify-end gap-1">P: <span className="text-zinc-300">{formatMoney(barber.breakdown.product)}</span></span>
                                          </div>
                                      </td>
                                  )}

                                  <td className="p-4 text-right">
                                      <div className="flex flex-col items-end">
                                          <span className="text-lg font-bold text-green-500">{formatMoney(barber.monthCommission)}</span>
                                          <span className="text-[10px] text-zinc-600">Calculado</span>
                                      </div>
                                  </td>
                              </tr>
                          ))}
                          {stats.monthlyCommissions.length === 0 && (
                              <tr>
                                  <td colSpan={isAdmin ? 4 : 5} className="p-8 text-center text-zinc-500">
                                      Nenhum profissional ativo ou dados insuficientes.
                                  </td>
                              </tr>
                          )}
                      </tbody>
                  </table>
              </div>
          </div>

      </div>
    </div>
  );
};

export default AdminDashboard;