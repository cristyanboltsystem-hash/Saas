import React, { useState, useEffect, useMemo } from 'react';
import { storage } from '../../utils/storage';
import { Appointment, Service, Barber, PaymentMethod } from '../../types';
import { 
  Check, X, Calendar, ChevronLeft, ChevronRight, 
  Lock, UserPlus, Unlock, Search, Phone, DollarSign, Edit3, AlertCircle, Trash2, Clock
} from 'lucide-react';

// --- Helpers ---
const generateDaySlots = () => {
  const slots = [];
  for (let h = 8; h < 20; h++) {
    slots.push(`${h.toString().padStart(2, '0')}:00`);
    slots.push(`${h.toString().padStart(2, '0')}:30`);
  }
  return slots;
};

const formatDateToLocalISO = (date: Date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const generateId = () => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
};

const AdminAppointments: React.FC = () => {
  // --- Auth State ---
  const role = sessionStorage.getItem('userRole');
  const userId = sessionStorage.getItem('userId');
  const isAdmin = role === 'ADMIN';

  // --- Data State ---
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [barbers, setBarbers] = useState<Barber[]>([]);

  // --- UI State ---
  const [selectedDate, setSelectedDate] = useState(new Date());
  // If not admin, lock selection to the user's ID
  const [selectedBarberId, setSelectedBarberId] = useState<string>('all');

  useEffect(() => {
    if (!isAdmin && userId) {
        setSelectedBarberId(userId);
    }
  }, [isAdmin, userId]);
  
  // --- Modal States ---
  const [activeTimeSlot, setActiveTimeSlot] = useState<string | null>(null);
  
  // 1. Booking Modal
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [newBookingData, setNewBookingData] = useState({
    clientName: '', clientPhone: '', serviceId: '', barberId: '', time: ''
  });

  // 2. Block Modal
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [blockData, setBlockData] = useState({ recurring: false, reason: '' });

  // 3. Payment/Details Modal
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [paymentData, setPaymentData] = useState({
    method: 'money' as PaymentMethod,
    discount: 0,
    tip: 0
  });

  // --- Swipe Logic ---
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const minSwipeDistance = 50;

  const onTouchStart = (e: React.TouchEvent) => { setTouchEnd(null); setTouchStart(e.targetTouches[0].clientX); };
  const onTouchMove = (e: React.TouchEvent) => setTouchEnd(e.targetTouches[0].clientX);
  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    if (distance > minSwipeDistance) changeDate(1);
    if (distance < -minSwipeDistance) changeDate(-1);
  };

  // --- Initialization ---
  useEffect(() => { refreshData(); }, []);

  const refreshData = () => {
    setAppointments(storage.getAppointments());
    setServices(storage.getServices());
    setBarbers(storage.getBarbers());
  };

  // --- Derived State ---
  const dateKey = formatDateToLocalISO(selectedDate);
  const formattedDate = useMemo(() => selectedDate.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' }), [selectedDate]);
  
  const dayAppointments = useMemo(() => {
    return appointments.filter(app => {
        const matchesDate = app.date === dateKey;
        const matchesBarber = selectedBarberId === 'all' || app.barberId === selectedBarberId;
        const isActive = app.status !== 'cancelled';
        return matchesDate && matchesBarber && isActive;
    });
  }, [appointments, dateKey, selectedBarberId]);

  const stats = useMemo(() => {
    const active = dayAppointments.filter(a => a.status !== 'blocked');
    const revenue = active.reduce((acc, curr) => acc + (curr.finalPrice || curr.totalPrice || 0), 0);
    return {
      total: active.length,
      pending: active.filter(a => a.status === 'confirmed' || a.status === 'pending').length,
      completed: active.filter(a => a.status === 'completed').length,
      revenue
    };
  }, [dayAppointments]);

  // --- Navigation ---
  const changeDate = (days: number) => {
    const newDate = new Date(selectedDate);
    newDate.setDate(selectedDate.getDate() + days);
    setSelectedDate(newDate);
  };

  // --- Actions: Booking ---
  const openBookingModal = (time: string) => {
    // If 'All' is selected, default to first barber, otherwise selected barber
    const defaultBarberId = selectedBarberId === 'all' ? (barbers[0]?.id || '') : selectedBarberId;
    
    setNewBookingData({
        clientName: '', clientPhone: '', serviceId: services[0]?.id || '',
        barberId: defaultBarberId, time: time
    });
    setActiveTimeSlot(time);
    setShowBookingModal(true);
  };

  const handleSaveBooking = () => {
    if(!newBookingData.clientName || !newBookingData.serviceId || !newBookingData.barberId) return;
    const service = services.find(s => s.id === newBookingData.serviceId);
    const newApp: Appointment = {
        id: generateId(),
        serviceId: newBookingData.serviceId,
        barberId: newBookingData.barberId,
        date: dateKey,
        time: newBookingData.time,
        client: { name: newBookingData.clientName, phone: newBookingData.clientPhone },
        status: 'confirmed', // Shows as Orange (Pending)
        totalPrice: service?.price || 0,
        createdAt: new Date().toISOString()
    };
    storage.saveAppointment(newApp);
    refreshData();
    setShowBookingModal(false);
  };

  // --- Actions: Blocking ---
  const openBlockModal = (time: string) => {
    setActiveTimeSlot(time);
    setBlockData({ recurring: false, reason: '' });
    setShowBlockModal(true);
  };

  const handleBlockTime = () => {
    if (!activeTimeSlot || selectedBarberId === 'all') {
        alert("Selecione um barbeiro específico para bloquear a agenda.");
        return;
    }

    const newBlocks: Appointment[] = [];
    // If recurring, block for next 12 weeks (approx 3 months)
    const iterations = blockData.recurring ? 12 : 1; 

    for(let i=0; i<iterations; i++) {
        const d = new Date(selectedDate);
        d.setDate(d.getDate() + (i * 7));
        const dKey = formatDateToLocalISO(d);

        newBlocks.push({
            id: generateId(),
            serviceId: 'blocked',
            barberId: selectedBarberId,
            date: dKey,
            time: activeTimeSlot,
            client: { name: 'Bloqueio', phone: '' },
            status: 'blocked',
            totalPrice: 0,
            notes: blockData.reason,
            createdAt: new Date().toISOString()
        });
    }

    const currentApps = storage.getAppointments();
    storage.updateAppointments([...currentApps, ...newBlocks]);
    refreshData();
    setShowBlockModal(false);
  };

  // --- Actions: Payment / Details ---
  const openDetailsModal = (app: Appointment) => {
    setSelectedAppointment(app);
    // Initialize form with existing values or defaults
    setPaymentData({
        method: app.paymentMethod || 'money',
        discount: app.discount || 0,
        tip: app.tip || 0
    });
  };

  const closeDetailsModal = () => {
    setSelectedAppointment(null);
  };

  const handleCancelAppointment = () => {
    if(!selectedAppointment) return;
    if(window.confirm('Tem certeza que deseja cancelar este agendamento? O horário ficará livre.')) {
        const updated = appointments.map(a => a.id === selectedAppointment.id ? { ...a, status: 'cancelled' as const } : a);
        storage.updateAppointments(updated);
        refreshData();
        closeDetailsModal();
    }
  };

  const handleDeleteBlock = (id: string) => {
     if(window.confirm('Desbloquear este horário?')) {
        const updated = appointments.map(a => a.id === id ? { ...a, status: 'cancelled' as const } : a);
        storage.updateAppointments(updated);
        refreshData();
     }
  };

  const handleCompletePayment = () => {
    if(!selectedAppointment) return;

    const basePrice = selectedAppointment.totalPrice;
    const finalPrice = Math.max(0, basePrice - paymentData.discount) + paymentData.tip;
    
    // Check if this appointment was already completed to avoid double XP
    const wasCompleted = selectedAppointment.status === 'completed';

    const updated = appointments.map(a => a.id === selectedAppointment.id ? {
        ...a,
        status: 'completed' as const,
        paymentMethod: paymentData.method,
        discount: paymentData.discount,
        tip: paymentData.tip,
        finalPrice: finalPrice
    } : a);

    storage.updateAppointments(updated);
    
    // AWARD XP TO CLIENT
    if (!wasCompleted && selectedAppointment.clientId) {
        storage.awardXpToClient(selectedAppointment.clientId);
    }

    refreshData();
    closeDetailsModal();
  };

  // --- Render Helpers ---
  const getServiceName = (id: string) => services.find(s => s.id === id)?.name;
  const getBarberName = (id: string) => barbers.find(b => b.id === id)?.name;

  return (
    <div className="space-y-4 pb-20 select-none" onTouchStart={onTouchStart} onTouchMove={onTouchMove} onTouchEnd={onTouchEnd}>
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Agenda</h1>
        <div className="mt-4 bg-zinc-900 border border-zinc-800 rounded-xl p-3 flex items-center justify-between shadow-lg">
            <button onClick={() => changeDate(-1)} className="p-3 text-zinc-400 hover:text-white bg-zinc-800/50 rounded-lg"><ChevronLeft/></button>
            <div className="flex flex-col items-center">
                <span className="text-white font-medium capitalize flex items-center gap-2 text-lg">
                    <Calendar size={18} className="text-amber-500"/>
                    {formattedDate}
                </span>
                {dateKey === formatDateToLocalISO(new Date()) && (
                    <span className="text-xs text-green-500 font-bold tracking-wider uppercase mt-1">Hoje</span>
                )}
            </div>
            <button onClick={() => changeDate(1)} className="p-3 text-zinc-400 hover:text-white bg-zinc-800/50 rounded-lg"><ChevronRight/></button>
        </div>
      </div>

      {/* Barber Selector - Only Show if Admin */}
      {isAdmin && (
          <div className="flex overflow-x-auto gap-3 py-2 scrollbar-hide">
            <div 
                onClick={() => setSelectedBarberId('all')}
                className={`flex flex-col items-center min-w-[70px] cursor-pointer transition-all ${selectedBarberId === 'all' ? 'opacity-100 scale-105' : 'opacity-60 scale-100'}`}
            >
                <div className={`w-16 h-16 rounded-full flex items-center justify-center border-2 mb-2 shadow-lg ${selectedBarberId === 'all' ? 'border-amber-500 bg-zinc-800' : 'border-zinc-700 bg-zinc-900'}`}>
                    <Search size={24} className="text-white"/>
                </div>
                <span className="text-xs text-white font-medium">Todos</span>
            </div>
            
            {barbers.filter(b => b.active).map(barber => (
                <div 
                    key={barber.id}
                    onClick={() => setSelectedBarberId(barber.id)}
                    className={`flex flex-col items-center min-w-[70px] cursor-pointer transition-all ${selectedBarberId === barber.id ? 'opacity-100 scale-105' : 'opacity-60 scale-100'}`}
                >
                    <img 
                        src={barber.photoUrl} 
                        className={`w-16 h-16 rounded-full object-cover border-2 mb-2 shadow-lg ${selectedBarberId === barber.id ? 'border-amber-500' : 'border-zinc-700'}`}
                        alt={barber.name}
                    />
                    <span className="text-xs text-white font-medium truncate w-full text-center">{barber.name.split(' ')[0]}</span>
                </div>
            ))}
          </div>
      )}

      {/* Stats Bar */}
      <div className="flex justify-between bg-zinc-900 p-4 rounded-xl border border-zinc-800 shadow-sm">
         <div className="text-center">
             <span className="text-2xl font-bold text-white block">{stats.total}</span>
             <span className="text-xs text-zinc-500 uppercase tracking-wider">Total</span>
         </div>
         <div className="text-center border-l border-zinc-800 pl-4">
             <span className="text-2xl font-bold text-amber-500 block">{stats.pending}</span>
             <span className="text-xs text-zinc-500 uppercase tracking-wider">Pendentes</span>
         </div>
         <div className="text-center border-l border-zinc-800 pl-4">
             <span className="text-2xl font-bold text-green-500 block">{stats.completed}</span>
             <span className="text-xs text-zinc-500 uppercase tracking-wider">Atendidos</span>
         </div>
         <div className="text-center border-l border-zinc-800 pl-4 hidden sm:block">
             <span className="text-2xl font-bold text-zinc-300 block">R$ {stats.revenue}</span>
             <span className="text-xs text-zinc-500 uppercase tracking-wider">Caixa</span>
         </div>
      </div>

      {/* --- Time Slots List --- */}
      <div className="space-y-3 mt-4">
         {generateDaySlots().map(slotTime => {
            // Find appointments in this slot
            // If 'all' barbers selected, we might have multiple. If single barber, only one max (or overlap if bug)
            // For UI simplicity in 'all' view, we show a list if multiple, or slots if single.
            // Requirement said "Centralized", let's stick to a strict slot view.
            
            // Filter apps for this specific slot
            const slotApps = dayAppointments.filter(a => a.time === slotTime);
            
            // If Specific Barber Selected (or forced by auth):
            if (selectedBarberId !== 'all') {
                const app = slotApps[0]; // Should only be one per barber per slot
                const isBlocked = app?.status === 'blocked';
                const isOccupied = !!app;

                // Color Logic
                let containerClass = "bg-zinc-900/50 border-zinc-800/50 border-dashed"; // Empty
                if (isBlocked) containerClass = "bg-red-900/10 border-red-900/40";
                else if (app?.status === 'completed') containerClass = "bg-green-900/10 border-green-900/40";
                else if (isOccupied) containerClass = "bg-amber-900/10 border-amber-900/40"; // Pending/Confirmed

                return (
                    <div key={slotTime} className={`min-h-[72px] rounded-xl border flex items-stretch relative overflow-hidden transition-all ${containerClass}`}>
                        {/* Time */}
                        <div className="w-20 flex-shrink-0 flex items-center justify-center border-r border-zinc-800/30 bg-black/20">
                            <span className={`font-mono font-bold text-lg ${isBlocked ? 'text-red-400' : 'text-zinc-400'}`}>{slotTime}</span>
                        </div>

                        {/* Content Area */}
                        <div 
                            className="flex-1 p-3 flex items-center justify-between cursor-pointer active:bg-white/5"
                            onClick={() => {
                                if (!isOccupied) openBookingModal(slotTime);
                                else if (isBlocked) handleDeleteBlock(app.id); // Or view details
                                else openDetailsModal(app);
                            }}
                        >
                            {isOccupied ? (
                                isBlocked ? (
                                    <div className="flex flex-col justify-center">
                                        <div className="flex items-center text-red-400 font-bold mb-1">
                                            <Lock size={16} className="mr-2"/> Bloqueado
                                        </div>
                                        {app.notes && <span className="text-xs text-red-400/70 italic">{app.notes}</span>}
                                    </div>
                                ) : (
                                    <div className="flex flex-col">
                                        <div className="flex items-center gap-2">
                                            <span className={`font-bold text-lg ${app.status === 'completed' ? 'text-green-500' : 'text-amber-500'}`}>
                                                {app.client.name}
                                            </span>
                                            {app.clientId && <div className="px-1.5 py-0.5 rounded-full bg-blue-500/20 text-blue-400 text-[10px] font-bold border border-blue-500/30">Membro</div>}
                                            {app.status === 'completed' && <Check size={16} className="text-green-500"/>}
                                        </div>
                                        <div className="text-xs text-zinc-500 flex items-center gap-2 mt-1">
                                            <span className="bg-zinc-800 px-2 py-0.5 rounded text-zinc-300">{getServiceName(app.serviceId)}</span>
                                            {app.client.phone && <span className="flex items-center"><Phone size={10} className="mr-1"/> {app.client.phone}</span>}
                                        </div>
                                    </div>
                                )
                            ) : (
                                <span className="text-zinc-600 font-medium flex items-center">
                                    <UserPlus size={16} className="mr-2 opacity-50"/> Disponível
                                </span>
                            )}

                            {/* Chevron or Icon to indicate action */}
                            {!isBlocked && (
                                <div className="text-zinc-600">
                                    {isOccupied ? <Edit3 size={18} /> : <ChevronRight size={18} />}
                                </div>
                            )}
                            {isBlocked && <Trash2 size={18} className="text-red-800/50" />}
                        </div>

                         {/* Quick Lock Button (Only if empty) */}
                         {!isOccupied && (
                            <button 
                                onClick={(e) => { e.stopPropagation(); openBlockModal(slotTime); }}
                                className="w-12 flex items-center justify-center border-l border-zinc-800/30 text-zinc-700 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                            >
                                <Lock size={18}/>
                            </button>
                        )}
                    </div>
                );
            } else {
                // 'All' view: Show list of appointments in this slot, or 'Empty' if none
                if (slotApps.length === 0) return null; // Don't show empty slots in 'All' view to save space? Or show them? 
                // Let's show only slots that have events.
                
                return slotApps.map(app => {
                    const isBlocked = app.status === 'blocked';
                    let borderColor = isBlocked ? 'border-red-900/40 bg-red-900/10' : (app.status === 'completed' ? 'border-green-900/40 bg-green-900/10' : 'border-amber-900/40 bg-amber-900/10');
                    
                    return (
                        <div key={app.id} 
                            onClick={() => isBlocked ? handleDeleteBlock(app.id) : openDetailsModal(app)}
                            className={`p-3 rounded-xl border ${borderColor} flex items-center gap-4 relative cursor-pointer`}
                        >
                             <div className="w-16 text-center">
                                <span className="font-mono font-bold text-zinc-300 block">{app.time}</span>
                             </div>
                             
                             <img 
                                src={barbers.find(b => b.id === app.barberId)?.photoUrl} 
                                className="w-10 h-10 rounded-full border border-zinc-700 object-cover"
                             />

                             <div className="flex-1">
                                {isBlocked ? (
                                    <span className="text-red-400 font-bold flex items-center gap-2"><Lock size={14}/> Bloqueado <span className="text-xs font-normal text-zinc-500">({getBarberName(app.barberId)})</span></span>
                                ) : (
                                    <div>
                                        <div className="flex justify-between items-start">
                                            <h3 className={`font-bold ${app.status === 'completed' ? 'text-green-500' : 'text-amber-500'}`}>{app.client.name}</h3>
                                            {app.status === 'completed' && <span className="text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded">Pago</span>}
                                        </div>
                                        <p className="text-zinc-400 text-xs mt-0.5">
                                            {getServiceName(app.serviceId)} com {getBarberName(app.barberId)}
                                        </p>
                                    </div>
                                )}
                             </div>
                        </div>
                    );
                });
            }
         })}

         {/* Empty State for 'All' view */}
         {selectedBarberId === 'all' && dayAppointments.length === 0 && (
             <div className="text-center py-20 opacity-50">
                 <Calendar size={48} className="mx-auto mb-4 text-zinc-600"/>
                 <p className="text-zinc-500">Nenhum agendamento para hoje.</p>
                 <button onClick={() => openBookingModal('09:00')} className="mt-4 text-amber-500 font-bold">Criar Agendamento</button>
             </div>
         )}
      </div>


      {/* --- MODALS --- */}

      {/* 1. New Booking Modal */}
      {showBookingModal && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-end sm:items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-zinc-900 border border-zinc-700 w-full max-w-md rounded-2xl p-6 animate-in slide-in-from-bottom-10">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-bold text-white">Novo Agendamento</h3>
                    <button onClick={() => setShowBookingModal(false)} className="text-zinc-500"><X/></button>
                </div>
                
                <div className="space-y-4">
                    <div className="flex gap-4">
                        <div className="w-24">
                            <label className="text-xs text-zinc-400 uppercase font-bold">Hora</label>
                            <input type="time" disabled value={newBookingData.time} className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-white mt-1 opacity-50 text-center font-mono"/>
                        </div>
                        <div className="flex-1">
                             <label className="text-xs text-zinc-400 uppercase font-bold">Profissional</label>
                             <select 
                                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-white mt-1"
                                value={newBookingData.barberId}
                                disabled={!isAdmin} // Lock selection for barbers
                                onChange={e => setNewBookingData({...newBookingData, barberId: e.target.value})}
                            >
                                {barbers.filter(b => b.active).map(b => (
                                    <option key={b.id} value={b.id}>{b.name}</option>
                                ))}
                            </select>
                        </div>
                    </div>

                    <div>
                        <label className="text-xs text-zinc-400 uppercase font-bold">Serviço</label>
                         <select 
                                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-white mt-1"
                                value={newBookingData.serviceId}
                                onChange={e => setNewBookingData({...newBookingData, serviceId: e.target.value})}
                            >
                                {services.filter(s => s.type === 'service' || s.type === 'subscription').map(s => (
                                    <option key={s.id} value={s.id}>{s.name} - R$ {s.price}</option>
                                ))}
                            </select>
                    </div>

                    <div>
                        <label className="text-xs text-zinc-400 uppercase font-bold">Cliente</label>
                        <input 
                            type="text" 
                            placeholder="Nome do cliente"
                            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-white mt-1"
                            value={newBookingData.clientName}
                            onChange={e => setNewBookingData({...newBookingData, clientName: e.target.value})}
                        />
                    </div>
                    <div>
                        <label className="text-xs text-zinc-400 uppercase font-bold">Telefone</label>
                        <input 
                            type="tel" 
                            placeholder="(00) 00000-0000"
                            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-white mt-1"
                            value={newBookingData.clientPhone}
                            onChange={e => setNewBookingData({...newBookingData, clientPhone: e.target.value})}
                        />
                    </div>

                    <button 
                        onClick={handleSaveBooking}
                        disabled={!newBookingData.clientName || !newBookingData.barberId}
                        className="w-full bg-amber-500 hover:bg-amber-400 text-zinc-900 font-bold py-4 rounded-xl mt-4 disabled:opacity-50"
                    >
                        Confirmar Agendamento
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* 2. Block Modal */}
      {showBlockModal && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-end sm:items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-zinc-900 border border-zinc-700 w-full max-w-sm rounded-2xl p-6">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold text-white flex items-center gap-2"><Lock size={20}/> Bloquear Horário</h3>
                    <button onClick={() => setShowBlockModal(false)} className="text-zinc-500"><X/></button>
                </div>
                
                <p className="text-zinc-300 mb-6 text-sm">
                    Bloquear agenda de <strong>{getBarberName(selectedBarberId)}</strong> às <strong>{activeTimeSlot}</strong>?
                </p>
                
                <div className="space-y-4">
                    <div>
                        <label className="text-xs text-zinc-400 uppercase font-bold">Motivo (Opcional)</label>
                        <input 
                            type="text" 
                            placeholder="Ex: Almoço, Médico..."
                            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-white mt-1"
                            value={blockData.reason}
                            onChange={e => setBlockData({...blockData, reason: e.target.value})}
                        />
                    </div>

                    <div className="bg-zinc-950 p-4 rounded-lg flex items-start gap-3 border border-zinc-800">
                        <input 
                            type="checkbox" 
                            id="recurring"
                            className="mt-1 w-5 h-5 rounded border-zinc-700 bg-zinc-800 text-amber-500 focus:ring-amber-500"
                            checked={blockData.recurring}
                            onChange={e => setBlockData({...blockData, recurring: e.target.checked})}
                        />
                        <label htmlFor="recurring" className="text-sm text-zinc-300">
                            <strong>Repetir toda semana?</strong>
                            <p className="text-xs text-zinc-500">Bloqueará todas as {selectedDate.toLocaleDateString('pt-BR', {weekday: 'long'})}s neste horário.</p>
                        </label>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4">
                        <button onClick={() => setShowBlockModal(false)} className="py-3 text-zinc-400 font-medium hover:text-white bg-zinc-800 rounded-lg">Cancelar</button>
                        <button onClick={handleBlockTime} className="py-3 bg-red-600 hover:bg-red-500 text-white rounded-lg font-bold">Confirmar Bloqueio</button>
                    </div>
                </div>
            </div>
        </div>
      )}

      {/* 3. Payment / Details Modal */}
      {selectedAppointment && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 backdrop-blur-sm">
            <div className="bg-zinc-900 border-t sm:border border-zinc-700 w-full max-w-md rounded-t-2xl sm:rounded-2xl p-6 h-[85vh] sm:h-auto overflow-y-auto">
                <div className="flex justify-between items-start mb-6">
                    <div>
                        <h3 className="text-xl font-bold text-white">{selectedAppointment.client.name}</h3>
                        <p className="text-zinc-400 text-sm">{getServiceName(selectedAppointment.serviceId)}</p>
                        {selectedAppointment.clientId && <span className="text-[10px] text-blue-400 font-bold uppercase mt-1 block">Membro Registrado (Ganha XP)</span>}
                    </div>
                    <button onClick={closeDetailsModal} className="p-2 bg-zinc-800 rounded-full text-zinc-400"><X size={20}/></button>
                </div>

                <div className="space-y-6">
                    {/* Status Indicator */}
                    <div className={`p-4 rounded-lg flex items-center justify-between border ${
                        selectedAppointment.status === 'completed' 
                        ? 'bg-green-500/10 border-green-500/30' 
                        : 'bg-amber-500/10 border-amber-500/30'
                    }`}>
                        <span className={`font-bold flex items-center gap-2 ${selectedAppointment.status === 'completed' ? 'text-green-500' : 'text-amber-500'}`}>
                            {selectedAppointment.status === 'completed' ? <Check size={20}/> : <Clock size={20}/>}
                            {selectedAppointment.status === 'completed' ? 'Atendido / Pago' : 'Aguardando Atendimento'}
                        </span>
                        {selectedAppointment.status === 'confirmed' && (
                             <span className="text-xs bg-zinc-900 text-zinc-400 px-2 py-1 rounded">Pendente</span>
                        )}
                    </div>

                    {/* Form for Payments */}
                    <div className="space-y-4">
                        <h4 className="text-zinc-500 text-xs font-bold uppercase tracking-wider">Pagamento</h4>
                        
                        <div className="grid grid-cols-2 gap-2">
                             {['money', 'pix', 'card', 'other'].map(method => (
                                 <button 
                                    key={method}
                                    onClick={() => setPaymentData({...paymentData, method: method as PaymentMethod})}
                                    className={`py-3 px-4 rounded-lg text-sm font-medium border transition-all ${
                                        paymentData.method === method 
                                        ? 'bg-amber-500 border-amber-500 text-zinc-900 font-bold' 
                                        : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                                    }`}
                                 >
                                     {method === 'money' && 'Dinheiro'}
                                     {method === 'pix' && 'Pix'}
                                     {method === 'card' && 'Cartão'}
                                     {method === 'other' && 'Outro'}
                                 </button>
                             ))}
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-xs text-zinc-400 uppercase font-bold">Desconto</label>
                                <div className="relative mt-1">
                                    <span className="absolute left-3 top-3 text-zinc-500 text-sm">R$</span>
                                    <input 
                                        type="number" 
                                        className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2.5 pl-9 text-white focus:border-amber-500 outline-none"
                                        value={paymentData.discount}
                                        onChange={e => setPaymentData({...paymentData, discount: Number(e.target.value)})}
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="text-xs text-zinc-400 uppercase font-bold">Gorjeta / Adicional</label>
                                <div className="relative mt-1">
                                    <span className="absolute left-3 top-3 text-zinc-500 text-sm">R$</span>
                                    <input 
                                        type="number" 
                                        className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2.5 pl-9 text-white focus:border-green-500 outline-none"
                                        value={paymentData.tip}
                                        onChange={e => setPaymentData({...paymentData, tip: Number(e.target.value)})}
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Total Summary */}
                        <div className="bg-zinc-950 p-4 rounded-lg space-y-2 border border-zinc-800">
                             <div className="flex justify-between text-zinc-400 text-sm">
                                 <span>Valor do Serviço</span>
                                 <span>R$ {selectedAppointment.totalPrice.toFixed(2)}</span>
                             </div>
                             {paymentData.discount > 0 && (
                                <div className="flex justify-between text-red-400 text-sm">
                                    <span>Desconto</span>
                                    <span>- R$ {paymentData.discount.toFixed(2)}</span>
                                </div>
                             )}
                             {paymentData.tip > 0 && (
                                <div className="flex justify-between text-green-400 text-sm">
                                    <span>Adicional</span>
                                    <span>+ R$ {paymentData.tip.toFixed(2)}</span>
                                </div>
                             )}
                             <div className="flex justify-between text-white font-bold text-lg pt-2 border-t border-zinc-800 mt-2">
                                 <span>Total Final</span>
                                 <span>R$ {(Math.max(0, selectedAppointment.totalPrice - paymentData.discount) + paymentData.tip).toFixed(2)}</span>
                             </div>
                        </div>
                    </div>
                    
                    {/* Action Buttons */}
                    <div className="grid grid-cols-1 gap-3 pt-2">
                        <button 
                            onClick={handleCompletePayment}
                            className={`w-full py-4 rounded-xl font-bold text-lg transition-colors flex items-center justify-center gap-2 ${
                                selectedAppointment.status === 'completed'
                                ? 'bg-zinc-800 text-white border border-zinc-600 hover:bg-zinc-700' // Edit mode
                                : 'bg-green-600 text-white hover:bg-green-500' // Complete mode
                            }`}
                        >
                           {selectedAppointment.status === 'completed' ? (
                               <><Edit3 size={20}/> Atualizar Valores / Salvar</>
                           ) : (
                               <><Check size={20}/> Confirmar Atendimento & Pagamento</>
                           )}
                        </button>

                        <button 
                            onClick={handleCancelAppointment}
                            className="w-full py-3 text-red-400 font-medium hover:bg-red-500/10 rounded-xl transition-colors"
                        >
                            Cancelar Agendamento
                        </button>
                    </div>
                </div>
            </div>
        </div>
      )}

    </div>
  );
};

export default AdminAppointments;