import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock } from 'lucide-react';
import { storage } from '../../utils/storage';

const AdminLogin: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // 1. Check Admin Hardcoded
    if (username === 'admin' && password === 'admin') {
      sessionStorage.setItem('userRole', 'ADMIN');
      sessionStorage.removeItem('userId');
      navigate('/admin/dashboard');
      return;
    }

    // 2. Check Barbers
    const barbers = storage.getBarbers();
    const barber = barbers.find(b => 
      b.username === username && 
      b.password === password && 
      b.active // Only active barbers can login
    );

    if (barber) {
      sessionStorage.setItem('userRole', 'BARBER');
      sessionStorage.setItem('userId', barber.id);
      navigate('/admin/dashboard');
      return;
    }

    setError('Credenciais inválidas.');
  };

  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-zinc-900 p-8 rounded-2xl border border-zinc-800 shadow-2xl">
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-amber-500 rounded-xl flex items-center justify-center mx-auto mb-4 text-zinc-900">
            <Lock size={24} />
          </div>
          <h1 className="text-2xl font-bold text-white">Acesso ao Sistema</h1>
          <p className="text-zinc-500 text-sm mt-2">Login Administrativo ou Profissional</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-zinc-400 text-sm mb-1">Usuário</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-white focus:border-amber-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-zinc-400 text-sm mb-1">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-3 text-white focus:border-amber-500 focus:outline-none"
            />
          </div>
          
          {error && <p className="text-red-400 text-sm text-center">{error}</p>}

          <button
            type="submit"
            className="w-full bg-amber-500 hover:bg-amber-400 text-zinc-900 font-bold py-3 rounded-lg transition-colors"
          >
            Entrar
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;