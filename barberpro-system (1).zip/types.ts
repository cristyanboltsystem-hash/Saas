
export type ItemType = 'service' | 'product';

export interface Service {
  id: string;
  name: string;
  price: number;
  durationMinutes: number; // 0 for products
  description?: string;
  type: ItemType;
  commissionRate?: number; 
  // New fields
  imageUrl?: string;
  costPrice?: number; // For products (to calculate profit)
  stock?: number; // For products
}

export interface Package {
  id: string;
  name: string;
  description: string;
  price: number;
  monthlyLimit: number; // How many services per month
  serviceIds: string[]; // IDs of services included in this package
}

export interface Subscriber {
  id: string;
  name: string;
  phone: string;
  packageId: string;
  barberId: string | 'any';
  startDate: string; // YYYY-MM-DD (Registration date)
  dueDay: number; // 1-31
  status: 'active' | 'expiring' | 'overdue' | 'inactive' | 'pending';
  lastPaymentAmount?: number;
  lastPaymentDate?: string;
  notes?: string;
}

export interface Barber {
  id: string;
  name: string;
  description?: string;
  photoUrl: string;
  phone: string;
  commissionRates: {
    service: number;
    product: number;
    subscription: number;
  };
  active: boolean;
  username?: string;
  password?: string;
}

export interface Client {
  name: string;
  phone: string;
  birthDate?: string;
}

// Gamification & Auth
export interface ClientAccount {
    id: string;
    name: string;
    phone: string; // Used as Login ID
    password?: string; // Simple password/pin
    birthDate?: string;
    photoUrl?: string;
    xp: number;
    level: number; // 1 to 10
    totalAppointments: number;
    joinedAt: string;
    referralCount?: number; // Number of friends referred
}

export interface LevelConfig {
    xpPerService: number; // How much XP a completed service gives
    levels: number[]; // Array of 9 numbers (XP needed for Level 2, 3... 10)
}

export type PaymentMethod = 'money' | 'pix' | 'card' | 'other';

export interface Appointment {
  id: string;
  serviceId: string;
  barberId: string;
  date: string;
  time: string;
  client: Client;
  clientId?: string; // Link to ClientAccount if logged in
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled' | 'blocked';
  totalPrice: number;
  finalPrice?: number;
  discount?: number;
  tip?: number;
  paymentMethod?: PaymentMethod;
  notes?: string;
  createdAt: string;
}