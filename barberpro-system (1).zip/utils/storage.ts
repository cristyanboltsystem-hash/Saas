import { Service, Barber, Appointment, Package, Subscriber, ClientAccount, LevelConfig } from '../types';

const KEYS = {
  SERVICES: 'barberpro_services',
  BARBERS: 'barberpro_barbers',
  APPOINTMENTS: 'barberpro_appointments',
  PACKAGES: 'barberpro_packages',
  SUBSCRIBERS: 'barberpro_subscribers',
  CLIENTS: 'barberpro_clients',
  LEVEL_CONFIG: 'barberpro_level_config',
};

// Seed Data
const INITIAL_SERVICES: Service[] = [
  { id: 's1', name: 'Corte de Cabelo', price: 50, durationMinutes: 30, description: 'Corte moderno com tesoura ou máquina.', type: 'service', imageUrl: 'https://images.unsplash.com/photo-1599351431202-1e0f0137899a?auto=format&fit=crop&q=80&w=200' },
  { id: 's2', name: 'Barba Completa', price: 40, durationMinutes: 30, description: 'Modelagem de barba com toalha quente.', type: 'service', imageUrl: 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&q=80&w=200' },
  { id: 's3', name: 'Combo (Cabelo + Barba)', price: 80, durationMinutes: 50, description: 'Pacote completo para o visual perfeito.', type: 'service', imageUrl: 'https://images.unsplash.com/photo-1503951914875-452162b7f300?auto=format&fit=crop&q=80&w=200' },
  { id: 'p1', name: 'Pomada Modeladora', price: 35, costPrice: 15, stock: 20, durationMinutes: 0, description: 'Alta fixação, efeito matte.', type: 'product', commissionRate: 15, imageUrl: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=200' },
  { id: 'p2', name: 'Óleo para Barba', price: 25, costPrice: 10, stock: 15, durationMinutes: 0, description: 'Hidratação e brilho.', type: 'product', commissionRate: 15, imageUrl: 'https://images.unsplash.com/photo-1629198688000-71f23e745b6e?auto=format&fit=crop&q=80&w=200' },
];

const INITIAL_PACKAGES: Package[] = [
    { id: 'pkg1', name: 'Mensal Básico', description: '4 Cortes por mês.', price: 150, monthlyLimit: 4, serviceIds: ['s1'] },
    { id: 'pkg2', name: 'Mensal VIP', description: 'Cortes e Barba ilimitados (Max 8)', price: 250, monthlyLimit: 8, serviceIds: ['s1', 's2', 's3'] },
];

const INITIAL_SUBSCRIBERS: Subscriber[] = [
    { 
        id: 'sub1', name: 'João Cliente', phone: '11999999999', 
        packageId: 'pkg1', barberId: 'any', 
        startDate: '2024-01-01', dueDay: 5,
        status: 'active', lastPaymentAmount: 150, lastPaymentDate: '2024-01-05'
    }
];

const INITIAL_BARBERS: Barber[] = [
  { 
    id: 'b1', 
    name: 'Carlos Silva', 
    description: 'Especialista em cortes clássicos e barboterapia.',
    photoUrl: 'https://images.unsplash.com/photo-1583900985737-6d1e13025682?auto=format&fit=crop&q=80&w=200', 
    phone: '11999999999', 
    commissionRates: { service: 50, product: 20, subscription: 10 },
    active: true, 
    username: 'carlos', 
    password: '123' 
  },
  { 
    id: 'b2', 
    name: 'Marcos Oliveira', 
    description: 'Mestre em degradês e cortes modernos.',
    photoUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&q=80&w=200', 
    phone: '11988888888', 
    commissionRates: { service: 45, product: 15, subscription: 5 },
    active: true, 
    username: 'marcos', 
    password: '123' 
  },
];

const INITIAL_LEVEL_CONFIG: LevelConfig = {
    xpPerService: 100,
    // XP needed to REACH level N. (Index 0 is for Level 2, Index 1 for Level 3...)
    levels: [100, 300, 600, 1000, 1500, 2100, 2800, 3600, 5000] 
};

export const storage = {
  getServices: (): Service[] => {
    const data = localStorage.getItem(KEYS.SERVICES);
    return data ? JSON.parse(data) : INITIAL_SERVICES;
  },
  saveServices: (services: Service[]) => {
    localStorage.setItem(KEYS.SERVICES, JSON.stringify(services));
  },
  
  getPackages: (): Package[] => {
    const data = localStorage.getItem(KEYS.PACKAGES);
    return data ? JSON.parse(data) : INITIAL_PACKAGES;
  },
  savePackages: (packages: Package[]) => {
    localStorage.setItem(KEYS.PACKAGES, JSON.stringify(packages));
  },

  getSubscribers: (): Subscriber[] => {
    const data = localStorage.getItem(KEYS.SUBSCRIBERS);
    return data ? JSON.parse(data) : INITIAL_SUBSCRIBERS;
  },
  saveSubscribers: (subscribers: Subscriber[]) => {
    localStorage.setItem(KEYS.SUBSCRIBERS, JSON.stringify(subscribers));
  },

  getBarbers: (): Barber[] => {
    const data = localStorage.getItem(KEYS.BARBERS);
    const barbers = data ? JSON.parse(data) : INITIAL_BARBERS;
    return barbers.map((b: Barber) => ({
        ...b,
        photoUrl: b.photoUrl || `https://ui-avatars.com/api/?name=${b.name}&background=random`
    }));
  },
  saveBarbers: (barbers: Barber[]) => {
    localStorage.setItem(KEYS.BARBERS, JSON.stringify(barbers));
  },

  getAppointments: (): Appointment[] => {
    const data = localStorage.getItem(KEYS.APPOINTMENTS);
    return data ? JSON.parse(data) : [];
  },
  saveAppointment: (appointment: Appointment) => {
    const appointments = storage.getAppointments();
    appointments.push(appointment);
    localStorage.setItem(KEYS.APPOINTMENTS, JSON.stringify(appointments));
  },
  updateAppointments: (appointments: Appointment[]) => {
    localStorage.setItem(KEYS.APPOINTMENTS, JSON.stringify(appointments));
  },

  // --- Gamification & Clients ---
  getClients: (): ClientAccount[] => {
      const data = localStorage.getItem(KEYS.CLIENTS);
      return data ? JSON.parse(data) : [];
  },
  saveClients: (clients: ClientAccount[]) => {
      localStorage.setItem(KEYS.CLIENTS, JSON.stringify(clients));
  },
  updateClient: (updatedClient: ClientAccount) => {
      const clients = storage.getClients();
      const newClients = clients.map(c => c.id === updatedClient.id ? updatedClient : c);
      storage.saveClients(newClients);
      // Update session if it's the current user
      const session = sessionStorage.getItem('clientSession');
      if (session) {
          const current = JSON.parse(session);
          if (current.id === updatedClient.id) {
              sessionStorage.setItem('clientSession', JSON.stringify(updatedClient));
          }
      }
  },
  
  getLevelConfig: (): LevelConfig => {
      const data = localStorage.getItem(KEYS.LEVEL_CONFIG);
      return data ? JSON.parse(data) : INITIAL_LEVEL_CONFIG;
  },
  saveLevelConfig: (config: LevelConfig) => {
      localStorage.setItem(KEYS.LEVEL_CONFIG, JSON.stringify(config));
  },

  // Helper to add XP
  awardXpToClient: (clientId: string) => {
      const clients = storage.getClients();
      const config = storage.getLevelConfig();
      
      const updatedClients = clients.map(client => {
          if (client.id === clientId) {
              const newXp = client.xp + config.xpPerService;
              let newLevel = client.level;
              
              // Calculate Level
              // Levels array index 0 = XP for Level 2.
              // We check from highest to lowest to find current level
              for (let i = config.levels.length - 1; i >= 0; i--) {
                  if (newXp >= config.levels[i]) {
                      newLevel = i + 2; // +2 because index 0 is level 2
                      break;
                  }
              }
              // If XP < first threshold, level remains 1
              if (newXp < config.levels[0]) newLevel = 1;

              return {
                  ...client,
                  xp: newXp,
                  level: Math.max(client.level, newLevel), // Never level down
                  totalAppointments: client.totalAppointments + 1
              };
          }
          return client;
      });
      storage.saveClients(updatedClients);
  },

  incrementReferralCount: (referrerId: string) => {
      const clients = storage.getClients();
      const updated = clients.map(c => {
          if (c.id === referrerId) {
              return { ...c, referralCount: (c.referralCount || 0) + 1 };
          }
          return c;
      });
      storage.saveClients(updated);
  },

  isTimeSlotAvailable: (barberId: string, date: string, time: string, durationMinutes: number): boolean => {
    const appointments = storage.getAppointments().filter(
      a => a.barberId === barberId && a.date === date && a.status !== 'cancelled'
    );
    const timeToMinutes = (t: string) => {
      const [h, m] = t.split(':').map(Number);
      return h * 60 + m;
    };
    const newStart = timeToMinutes(time);
    const newEnd = newStart + durationMinutes;

    return !appointments.some(app => {
      const services = storage.getServices();
      const service = services.find(s => s.id === app.serviceId);
      const appDuration = service ? service.durationMinutes : 30;
      const existingStart = timeToMinutes(app.time);
      const existingEnd = existingStart + appDuration;
      return (newStart < existingEnd && newEnd > existingStart);
    });
  },

  exportData: () => {
    return JSON.stringify({
      services: JSON.parse(localStorage.getItem(KEYS.SERVICES) || '[]'),
      packages: JSON.parse(localStorage.getItem(KEYS.PACKAGES) || '[]'),
      subscribers: JSON.parse(localStorage.getItem(KEYS.SUBSCRIBERS) || '[]'),
      barbers: JSON.parse(localStorage.getItem(KEYS.BARBERS) || '[]'),
      appointments: JSON.parse(localStorage.getItem(KEYS.APPOINTMENTS) || '[]'),
      clients: JSON.parse(localStorage.getItem(KEYS.CLIENTS) || '[]'),
      levelConfig: JSON.parse(localStorage.getItem(KEYS.LEVEL_CONFIG) || '{}'),
      exportedAt: new Date().toISOString()
    }, null, 2);
  },

  importData: (jsonString: string) => {
    try {
      const data = JSON.parse(jsonString);
      if (data.services) localStorage.setItem(KEYS.SERVICES, JSON.stringify(data.services));
      if (data.packages) localStorage.setItem(KEYS.PACKAGES, JSON.stringify(data.packages));
      if (data.subscribers) localStorage.setItem(KEYS.SUBSCRIBERS, JSON.stringify(data.subscribers));
      if (data.barbers) localStorage.setItem(KEYS.BARBERS, JSON.stringify(data.barbers));
      if (data.appointments) localStorage.setItem(KEYS.APPOINTMENTS, JSON.stringify(data.appointments));
      if (data.clients) localStorage.setItem(KEYS.CLIENTS, JSON.stringify(data.clients));
      if (data.levelConfig) localStorage.setItem(KEYS.LEVEL_CONFIG, JSON.stringify(data.levelConfig));
      return true;
    } catch (e) {
      return false;
    }
  }
};